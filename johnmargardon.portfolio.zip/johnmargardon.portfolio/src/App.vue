<template>
    <v-app id="inspire">
        <v-app-bar app elevation="0">
            <v-subheader><h1 class="Black--text">Portfolio<span class="White--text">.in</span></h1></v-subheader>
            <v-tabs center-active right background-color="transparent" active-class="active-tab">
                <v-tab href="#home">HOME</v-tab>
                <v-tab>ABOUT</v-tab>
                <v-tab>SKILLS</v-tab>
                <v-tab>INTEREST</v-tab>


            </v-tabs>
            <v-btn large color="Black" class="white--text ml-10">Message me </v-btn>
        </v-app-bar>
        <v-main style="background-color: #F5F5F5">
            <section class="intro-section" id="HOME">
                <v-row class="align-center px-10" style="height: 690px">
                    <v-col lg="6" cols="6" class="pa-6 font-weight-bold py-16">
                        <h2 class="display-3"> <span class="green--text"></span> & <span class="pink--text"></span>
                            </h2>
                        <v-subheader>Hello, I am John Mar,I'm not good enough .</v-subheader>
                        <br>
                        <br>
                        <v-btn large elevation="5" color="RED" class="white--text mt-10 px-10 py-5">message me</v-btn>
                        <v-btn large elevation="5" color="BLACK" class="whit--text mt-10 ml-10 px-10 py-5">Contact
                        </v-btn>
                       
                    </v-col>
                    <v-col lg="6" cols="6">
                        <v-img src="https://drive.google.com/file/d/1SPT5c3zdyBr_wrV_6aOB516XUxY4Wm11/view?usp=sharing"></v-img>
                    </v-col>
                </v-row>
            </section>
            <section class="about-me" id="about">
                <v-img class="pa-10" height="400" gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                       src="">
                    <v-row justify="center" class="align-center">
                        <v-col lg="6" cols="6">
                            <v-card class="text-center pa-6 rounded-lg" color="#e1e0e0c9" elevation="6">
                                <v-card-subtitle class="green--text">ABOUT MYSELF</v-card-subtitle>
                                <h2 class="display-1 font-weight-regular">
                                   I'M STILL LEARNING!
                                </h2>
                                <v-btn large elevation="5" color="pink" class="white--text mt-10 px-10 py-5">
                                    <v-icon></v-icon>
                                </v-btn>
                            </v-card>
                        </v-col>
                        <v-col lg="6" cols="6">
                            <v-card class="pa-6 rounded-lg" color="#e1e0e0c9" elevation="6">
                                <div class="py-1" v-for="(item,index) in items" :key="index">
                                    <label>{{ item.title }}</label>
                                    <v-progress-linear
                                            :color="item.color"
                                            height="10"
                                            :value="item.value"
                                    ></v-progress-linear>
                                </div>
                            </v-card>
                        </v-col>
                    </v-row>
                </v-img>
            </section>
            <section class="educaion py-6">
                <v-container>
                    <h4 class="display-2 text-center">SKILLS</h4>
                    <v-row class="py-8">
                        <v-col cols="12" lg="6">
                            <v-card class="pa-6 rounded-xl " elevation="5">
                                <div class="d-flex align-center justify-space-between">
                                    <div class="">
                                        <h2>Leadership</h2>
                                        <span>Self-motivation </span>
                                    </div>
                                    <a class="green--text"> <v-icon color="green"></v-icon></a>
                                </div>
                                <v-card-text>
                                    
                                </v-card-text>
                            </v-card>
                        </v-col>
                        <v-col cols="12" lg="6">
                            
                        </v-col>
                    </v-row>
                </v-container>
            </section>
            <section class="experiance py-6">
                <v-img class="pa-10" gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                       src="https://drive.google.com/file/d/1IBgDhFoJvoNL2BYdSq6aH2CMQIobwP8Q/view?usp=sharing">
                    <v-container>
                        <h4 class="display-2 text-center">Experience</h4>
                        <v-timeline>
                            <v-timeline-item v-for="(exper,index) in experience" :key="index"
                                             :color="index % 2 === 0 ?'Black':'Red'">
                                <v-card class="rounded-xl">
                                    <v-card-title :color="index % 2 === 0 ?'Black':'Red'">
                                        {{exper.title}}
                                    </v-card-title>
                                    Student assistant
                                    <v-card-text>
                                        <b>{{exper.date}}</b><br>
                                        <b>@{{exper.institute}}</b><br>
                                        {{exper.decription}}
                                    </v-card-text>
                                </v-card>
                            </v-timeline-item>
                        </v-timeline>
                    </v-container>
                </v-img>

            </section>
            <section class="portfolio">
                <h4 class="display-2 text-center">Portfolio</h4>
                <v-slide-group
                        class="pa-4"
                        active-class="success"
                        show-arrows
                >
                    <v-slide-item v-for="(slider,index) in sliders" :key="index">
                        <v-card height="250" width="250" class="mx-2">
                            <img height="100%" width="100%" :src="slider" alt="">
                        </v-card>
                    </v-slide-item>
                </v-slide-group>
            </section>
            <section class="contact-us pt-10">
                <v-img class="pt-10" gradient="to bottom, rgb(166 199 156), rgb(227 227 227 / 86%)" src="https://drive.google.com/file/d/1Mc_k8hinXU51KdLr6xHFQdx18sI9U5A3/view?usp=sharing">
                    <v-container>
                        <h4 class="display-1 text-center mb-5">
                           Name: John Mar O. Gardon
                           Age: 21
                           Address: Alabang Hills


                           i am a good listener
                        </h4>
                        <v-divider />
                        <br>
                        <v-row>
                            <v-col cols="12" lg="3" offset="2">
                                <v-card-title>Message me</v-card-title>
                                <v-card-text>
                                    18 cdo, Muntinlupa City <br>
                                    +369-6567-03660 <br>
                                    gardonjohnmar@gmail.com <br>
                                </v-card-text>
                                <v-card-actions>
                                    <v-btn large elevation="5" color="Black" class="white--text mt-10 px-10 py-5">
                                        <v-icon>d</v-icon>
                                    </v-btn>
                                </v-card-actions>
                            </v-col>
                        </v-row>
                    </v-container>
                    <v-footer class="mt-4">
                        <v-col
                                class="text-center"
                                cols="12"
                        >
                            <strong>{{ new Date().getFullYear() }} 
                                <a href="" class="green--text"></a>
                            </strong>
                        </v-col>
                    </v-footer>
                </v-img>
            </section>
        </v-main>
    </v-app>
</template>

<script>
    export default {
        name: 'App',

        data: () => ({
            drawer: null,
            items: [
                {title: 'HTML', value: 100, color: 'light-Black'},
                {title: 'CSS', value: 100, color: 'deep-orange'},
                {title: 'Javascript', value: 70, color: 'light-red'},
                {title: 'Vuejs', value: 80, color: 'white'},
                
               
            ],
            experience: [
                {
                    title: 'Student assistant',
                    date: 'June 2019',
                    
        
                },
               
            ],
            sliders:[
               
            ]
        }),
    }
</script>
<style>
    .v-tab.active-tab {
        color: #da0f0f;
    }

    .v-tab.active-tab::before {
        background-color: #0c0c0c;
    }
</style>